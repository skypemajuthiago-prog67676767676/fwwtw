package com.nowheredreams;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.BedBlock;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.network.PacketDistributor;

/** Salidas de cada nivel, límites de la caja de Beta y animación de muerte. */
public class DreamEvents {

    /** Secuencia de muerte en curso para un jugador. */
    private static final class Grab {
        final DreamCreature creature;
        final double x, y, z;
        int ticks = 0;
        boolean finishing = false;
        Grab(DreamCreature c, ServerPlayer p) { creature = c; x = p.getX(); y = p.getY(); z = p.getZ(); }
    }
    private static final Map<UUID, Grab> GRABS = new HashMap<>();
    private static final int GRAB_TICKS = 50;

    /** Si un golpe de una criatura te mataría: no mueres, te agarra y te levanta; después te corta la cabeza. */
    @SubscribeEvent(priority = EventPriority.HIGH)
    public void onHurt(LivingHurtEvent e) {
        if (!(e.getEntity() instanceof ServerPlayer sp)) return;
        Grab current = GRABS.get(sp.getUUID());
        if (current != null) { // durante la secuencia nada te daña, salvo el corte final
            if (!current.finishing) e.setCanceled(true);
            return;
        }
        if (sp.isCreative() || sp.isSpectator()) return;
        if (e.getSource().getEntity() instanceof DreamCreature dc && dc.getVariant() != CreatureVariant.CONE
                && e.getAmount() >= sp.getHealth() + sp.getAbsorptionAmount()) {
            e.setCanceled(true);
            GRABS.put(sp.getUUID(), new Grab(dc, sp));
        }
    }

    private void tickGrab(ServerPlayer sp, Grab g) {
        DreamCreature dc = g.creature;
        if (!dc.isAlive()) { GRABS.remove(sp.getUUID()); return; } // la mataron: te suelta
        g.ticks++;
        if (g.ticks == 1) {
            dc.setNoAi(true);
            Net.CHANNEL.send(PacketDistributor.PLAYER.with(() -> sp), new JumpscarePacket(dc.getVariant().ordinal(), true));
            sp.serverLevel().playSound(null, sp.blockPosition(), SoundEvents.WARDEN_ATTACK_IMPACT, SoundSource.HOSTILE, 2.0f, 0.6f);
        }
        // te levanta y te obliga a mirarla
        float lift = Math.min(g.ticks, 35) / 35f * 1.6f;
        float yaw = (float) (Mth.atan2(dc.getZ() - g.z, dc.getX() - g.x) * (180.0 / Math.PI)) - 90f;
        sp.connection.teleport(g.x, g.y + lift, g.z, yaw, -10f);
        sp.setDeltaMovement(Vec3.ZERO);
        sp.fallDistance = 0;

        if (g.ticks >= GRAB_TICKS) finishGrab(sp, g);
    }

    /** El corte: suena, cae la cabeza (objeto) y mueres. */
    private void finishGrab(ServerPlayer sp, Grab g) {
        g.finishing = true;
        DreamCreature dc = g.creature;
        dc.setNoAi(false);
        sp.serverLevel().playSound(null, sp.blockPosition(), SoundEvents.PLAYER_ATTACK_SWEEP, SoundSource.HOSTILE, 2.0f, 0.5f);
        sp.serverLevel().playSound(null, sp.blockPosition(), SoundEvents.PLAYER_ATTACK_CRIT, SoundSource.HOSTILE, 2.0f, 0.5f);

        ItemStack head = new ItemStack(Items.PLAYER_HEAD);
        head.getOrCreateTag().putString("SkullOwner", sp.getGameProfile().getName());
        ItemEntity drop = new ItemEntity(sp.serverLevel(), sp.getX(), sp.getY() + 1.6, sp.getZ(), head);
        drop.setDeltaMovement((sp.getRandom().nextDouble() - 0.5) * 0.2, 0.2, (sp.getRandom().nextDouble() - 0.5) * 0.2);
        sp.serverLevel().addFreshEntity(drop);

        sp.invulnerableTime = 0;
        sp.hurt(sp.damageSources().mobAttack(dc), Float.MAX_VALUE);
        GRABS.remove(sp.getUUID());
    }

    @SubscribeEvent
    public void onLogout(PlayerEvent.PlayerLoggedOutEvent e) {
        Grab g = GRABS.remove(e.getEntity().getUUID());
        if (g != null) g.creature.setNoAi(false);
    }

    /** Cuando una criatura te mata: susto a pantalla completa + sonido. */
    @SubscribeEvent
    public void onDeath(LivingDeathEvent e) {
        if (e.getEntity() instanceof ServerPlayer sp
                && e.getSource().getEntity() instanceof DreamCreature dc
                && dc.getVariant() != CreatureVariant.CONE) {
            Net.CHANNEL.send(PacketDistributor.PLAYER.with(() -> sp), new JumpscarePacket(dc.getVariant().ordinal(), false));
            sp.serverLevel().playSound(null, sp.blockPosition(), SoundEvents.ELDER_GUARDIAN_CURSE, SoundSource.HOSTILE, 2.0f, 0.5f);
        }
    }

    /** Liminal Halls: usar una cama.  Backrooms 92: tocar el centro naranja de un molinete. */
    @SubscribeEvent
    public void onRightClick(PlayerInteractEvent.RightClickBlock e) {
        if (e.getLevel().isClientSide || !(e.getEntity() instanceof ServerPlayer sp)) return;
        ResourceKey<Level> dim = e.getLevel().dimension();
        BlockState st = e.getLevel().getBlockState(e.getPos());
        boolean exit = (dim == ModDimensions.LIMINAL && st.getBlock() instanceof BedBlock)
                || (dim == ModDimensions.BACKROOMS && st.is(Blocks.ORANGE_CONCRETE));
        if (exit) {
            e.setCanceled(true);
            ModDimensions.travel(sp, Level.OVERWORLD);
        }
    }

    /** Dream Void: caer al vacío.  Beta Lands: llegar al techo; además no puedes salir de la caja. */
    @SubscribeEvent
    public void onPlayerTick(TickEvent.PlayerTickEvent e) {
        if (e.phase != TickEvent.Phase.END || !(e.player instanceof ServerPlayer sp)) return;
        Grab grab = GRABS.get(sp.getUUID());
        if (grab != null) { tickGrab(sp, grab); return; }
        ResourceKey<Level> dim = sp.level().dimension();

        if (dim == ModDimensions.VOID && sp.getY() < -8) {
            sp.fallDistance = 0;
            ModDimensions.travel(sp, Level.OVERWORLD);
        } else if (dim == ModDimensions.BETA) {
            if (sp.getY() >= com.nowheredreams.worldgen.DreamFeatures.BOX_TOP - 3) {
                ModDimensions.travel(sp, Level.OVERWORLD);
                return;
            }
            double lim = com.nowheredreams.worldgen.DreamFeatures.BOX_R - 1.0;
            double x = Mth.clamp(sp.getX(), -lim, lim), z = Mth.clamp(sp.getZ(), -lim, lim);
            if (x != sp.getX() || z != sp.getZ())
                sp.connection.teleport(x, sp.getY(), z, sp.getYRot(), sp.getXRot());
        }
    }
}
