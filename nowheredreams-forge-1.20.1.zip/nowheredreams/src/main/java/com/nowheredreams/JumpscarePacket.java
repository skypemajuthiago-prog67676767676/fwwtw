package com.nowheredreams;

import java.util.function.Supplier;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

/** Servidor -> cliente: animación de la criatura (grab = true: te agarra; false: susto de muerte). */
public class JumpscarePacket {
    private final int variant;
    private final boolean grab;

    public JumpscarePacket(int variant, boolean grab) { this.variant = variant; this.grab = grab; }

    public static void encode(JumpscarePacket msg, FriendlyByteBuf buf) { buf.writeVarInt(msg.variant); buf.writeBoolean(msg.grab); }
    public static JumpscarePacket decode(FriendlyByteBuf buf) { return new JumpscarePacket(buf.readVarInt(), buf.readBoolean()); }

    public static void handle(JumpscarePacket msg, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> {
            if (msg.grab) com.nowheredreams.client.Jumpscare.startGrab(msg.variant);
            else com.nowheredreams.client.Jumpscare.start(msg.variant);
        }));
        ctx.get().setPacketHandled(true);
    }
}
