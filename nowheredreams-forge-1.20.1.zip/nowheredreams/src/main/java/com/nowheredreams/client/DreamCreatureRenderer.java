package com.nowheredreams.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import com.nowheredreams.CreatureVariant;
import com.nowheredreams.DreamCreature;
import java.util.EnumMap;
import java.util.Map;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import org.joml.Matrix3f;
import org.joml.Matrix4f;
import org.joml.Quaternionf;

/**
 * Dibuja cada criatura como una lámina con su imagen (siempre de frente a la cámara, sin inclinarse).
 * Las que tienen pies (Locust, Sombrerero de Brazos y figura blanca) se dividen en cabeza, torso,
 * 2 piernas y 2 brazos, y esas piezas se mueven al caminar. Las demás solo se balancean.
 */
public class DreamCreatureRenderer extends EntityRenderer<DreamCreature> {

    /** Cortes de la imagen, como fracciones (0..1) desde la esquina superior izquierda. */
    private record Rig(float shoulder, float hip, float armL, float armR, float center) {}

    private static final Map<CreatureVariant, Rig> RIGS = new EnumMap<>(CreatureVariant.class);
    static {
        //                                      hombros  cadera  brazoIzq brazoDer centro
        RIGS.put(CreatureVariant.STILT,      new Rig(0.20f, 0.50f, 0.24f, 0.78f, 0.52f));
        RIGS.put(CreatureVariant.MANY_ARMS,  new Rig(0.18f, 0.52f, 0.36f, 0.66f, 0.52f));
        RIGS.put(CreatureVariant.BATH_GIANT, new Rig(0.20f, 0.48f, 0.22f, 0.78f, 0.50f));
    }

    private static final float LEG_SWING_DEG = 14f, ARM_SWING_DEG = 9f, LEG_LIFT = 0.025f;

    public DreamCreatureRenderer(EntityRendererProvider.Context ctx) {
        super(ctx);
        this.shadowRadius = 0.3f;
    }

    @Override
    public ResourceLocation getTextureLocation(DreamCreature e) { return e.getVariant().texture; }

    @Override
    public void render(DreamCreature e, float yaw, float partialTick, PoseStack ps, MultiBufferSource buffers, int light) {
        CreatureVariant v = e.getVariant();
        float t = e.tickCount + partialTick;
        float id = e.getId();

        float h = 1.95f * v.height * CreatureVariant.SCALE;
        float w = h * v.aspect;

        // --- animaciones dreamcore ---
        float sway = Mth.sin(t * 0.05f + id) * 3.0f;
        float breathe = 1.0f + Mth.sin(t * 0.08f + id) * 0.025f;
        boolean glitch = (((int) t + (int) id) % 70) < 3;
        float jitterX = glitch ? Mth.sin(t * 9f) * 0.12f : 0f;
        float stretch = glitch ? 1.0f + Mth.sin(t * 13f) * 0.06f : 1.0f;

        ps.pushPose();
        ps.mulPose(new Quaternionf().rotationY(-this.entityRenderDispatcher.camera.getYRot() * ((float) Math.PI / 180F)));
        ps.mulPose(Axis.YP.rotationDegrees(180.0F));
        ps.mulPose(Axis.ZP.rotationDegrees(sway));
        ps.translate(jitterX, 0, 0);
        ps.scale(1f, breathe * stretch, 1f);

        VertexConsumer vc = buffers.getBuffer(RenderType.entityCutoutNoCull(v.texture));
        Rig rig = RIGS.get(v);

        if (rig == null) { // sin pies visibles: una sola pieza
            piece(ps, vc, w, h, 0f, 0f, 1f, 1f, 0.5f, 1f, 0f, 0f, 0, light);
        } else {
            // ritmo de paso según lo rápido que se mueve
            double dx = e.getX() - e.xo, dz = e.getZ() - e.zo;
            float amount = Mth.clamp((float) Math.sqrt(dx * dx + dz * dz) * 10f, 0f, 1f);
            float swing = Mth.sin(t * 0.55f) * amount;
            float idle = Mth.sin(t * 0.06f + id) * 2.5f; // brazos se mecen aunque esté quieta

            float legA = LEG_SWING_DEG * swing;
            float armA = ARM_SWING_DEG * swing;
            float liftL = Math.max(0f, swing) * LEG_LIFT * h;
            float liftR = Math.max(0f, -swing) * LEG_LIFT * h;

            // piezas fijas
            piece(ps, vc, w, h, 0f, 0f, 1f, rig.shoulder, 0.5f, rig.shoulder, 0f, 0f, 0, light);                  // cabeza
            piece(ps, vc, w, h, rig.armL, rig.shoulder, rig.armR, rig.hip, 0.5f, rig.hip, 0f, 0f, 1, light);      // torso
            // brazos (pivote en el hombro, opuestos a la pierna del mismo lado)
            piece(ps, vc, w, h, 0f, rig.shoulder, rig.armL, 1f, rig.armL, rig.shoulder, -armA + idle, 0f, 2, light);
            piece(ps, vc, w, h, rig.armR, rig.shoulder, 1f, 1f, rig.armR, rig.shoulder, armA - idle, 0f, 3, light);
            // piernas (pivote en la cadera)
            float pivL = (rig.armL + rig.center) / 2f, pivR = (rig.center + rig.armR) / 2f;
            piece(ps, vc, w, h, rig.armL, rig.hip, rig.center, 1f, pivL, rig.hip, legA, liftL, 4, light);
            piece(ps, vc, w, h, rig.center, rig.hip, rig.armR, 1f, pivR, rig.hip, -legA, liftR, 5, light);
        }
        ps.popPose();

        super.render(e, yaw, partialTick, ps, buffers, light);
    }

    /**
     * Dibuja el rectángulo (u0,v0)-(u1,v1) de la imagen, girado angleDeg alrededor del pivote (pu,pv)
     * y levantado lift bloques. Coordenadas de imagen: u hacia la derecha, v hacia abajo.
     */
    private static void piece(PoseStack ps, VertexConsumer vc, float w, float h,
                              float u0, float v0, float u1, float v1,
                              float pu, float pv, float angleDeg, float lift, int order, int light) {
        float px = (pu - 0.5f) * w, py = (1f - pv) * h;
        ps.pushPose();
        ps.translate(px, py + lift, order * 0.004f); // separa un poco las piezas para que no parpadeen
        if (angleDeg != 0f) ps.mulPose(Axis.ZP.rotationDegrees(angleDeg));
        Matrix4f m = ps.last().pose();
        Matrix3f n = ps.last().normal();
        float x0 = (u0 - 0.5f) * w - px, x1 = (u1 - 0.5f) * w - px;
        float yTop = (1f - v0) * h - py, yBot = (1f - v1) * h - py;
        vertex(vc, m, n, x0, yBot, u0, v1, light);
        vertex(vc, m, n, x1, yBot, u1, v1, light);
        vertex(vc, m, n, x1, yTop, u1, v0, light);
        vertex(vc, m, n, x0, yTop, u0, v0, light);
        ps.popPose();
    }

    private static void vertex(VertexConsumer vc, Matrix4f m, Matrix3f n, float x, float y, float u, float v, int light) {
        vc.vertex(m, x, y, 0f).color(255, 255, 255, 255).uv(u, v)
                .overlayCoords(OverlayTexture.NO_OVERLAY).uv2(light).normal(n, 0f, 1f, 0f).endVertex();
    }
}
