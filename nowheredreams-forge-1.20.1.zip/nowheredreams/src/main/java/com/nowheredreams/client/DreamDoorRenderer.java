package com.nowheredreams.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.nowheredreams.DreamDoor;
import com.nowheredreams.NowhereDreams;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import org.joml.Matrix3f;
import org.joml.Matrix4f;
import org.joml.Quaternionf;

/** Dibuja la puerta como una lámina que brilla (siempre a máxima luz) y late suavemente. */
public class DreamDoorRenderer extends EntityRenderer<DreamDoor> {
    private static final ResourceLocation TEX = new ResourceLocation(NowhereDreams.MODID, "textures/entity/dream_door.png");
    private static final float HEIGHT = 2.6f, ASPECT = 64f / 112f;
    private static final int FULL_BRIGHT = 0xF000F0;

    public DreamDoorRenderer(EntityRendererProvider.Context ctx) { super(ctx); }

    @Override public ResourceLocation getTextureLocation(DreamDoor e) { return TEX; }

    @Override
    public void render(DreamDoor e, float yaw, float partialTick, PoseStack ps, MultiBufferSource buffers, int light) {
        float t = e.tickCount + partialTick;
        float pulse = 1.0f + Mth.sin(t * 0.1f) * 0.03f;
        float hw = HEIGHT * ASPECT / 2f * pulse;
        float top = HEIGHT * pulse;

        ps.pushPose();
        ps.mulPose(new Quaternionf().rotationY(-this.entityRenderDispatcher.camera.getYRot() * ((float) Math.PI / 180F)));
        ps.mulPose(com.mojang.math.Axis.YP.rotationDegrees(180.0F));
        PoseStack.Pose pose = ps.last();
        Matrix4f m = pose.pose();
        Matrix3f n = pose.normal();
        VertexConsumer vc = buffers.getBuffer(RenderType.entityCutoutNoCull(TEX));
        v(vc, m, n, -hw, 0f, 0f, 1f);
        v(vc, m, n, hw, 0f, 1f, 1f);
        v(vc, m, n, hw, top, 1f, 0f);
        v(vc, m, n, -hw, top, 0f, 0f);
        ps.popPose();
    }

    private static void v(VertexConsumer vc, Matrix4f m, Matrix3f n, float x, float y, float u, float v) {
        vc.vertex(m, x, y, 0f).color(255, 255, 255, 255).uv(u, v)
                .overlayCoords(OverlayTexture.NO_OVERLAY).uv2(FULL_BRIGHT).normal(n, 0f, 1f, 0f).endVertex();
    }
}
